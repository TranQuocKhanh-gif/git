﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Thread tcpServerThread = new Thread(serverThread);
            tcpServerThread.Start();
        }

        public void serverThread()
        {
            byte[] recv = new byte[1];
            int byteReceived = -1;
            Socket clientSocket;

            Socket listenerSocket = new Socket
                (
                AddressFamily.InterNetwork,
                SocketType.Stream,
                ProtocolType.Tcp
                );

            IPEndPoint ipepServer = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080);
            listenerSocket.Bind(ipepServer);

            listenerSocket.Listen(1);

            clientSocket = listenerSocket.Accept();

            infoMessage("Server running on " + ipepServer);
            infoMessage("New client connected");
            while (clientSocket.Connected && byteReceived != 0)
            {
                string text = "";

                do
                {
                    byteReceived = clientSocket.Receive(recv);
                    text += Encoding.UTF8.GetString(recv);
                } while (text[text.Length - 1] != '\n');

                infoMessage(text);
                
            }
            infoMessage("quit\n");
            clientSocket.Close();
           
        }

        public void infoMessage(string message)
        {
            ListViewItem item = new ListViewItem();
            item.Text = message;

            if (listMessage.InvokeRequired)
            {
                listMessage.Invoke(new MethodInvoker(delegate ()
                {
                    listMessage.Items.Add(item);
                }));
            }
            else
            {
                listMessage.Items.Add(item);
            }
        }

        private void listMessage_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
