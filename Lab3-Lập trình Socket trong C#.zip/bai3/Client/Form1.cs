﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSend_Click(object sender, EventArgs e)
        {
            TcpClient tcpClient = new TcpClient();

            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddress, 8080);
            tcpClient.Connect(ipEndPoint);

            NetworkStream stream = tcpClient.GetStream();

            Byte[] data = System.Text.Encoding.ASCII.GetBytes("Hello server\n");
            stream.Write(data, 0, data.Length);
            /*Byte[] Data = System.Text.Encoding.ASCII.GetBytes("quit\n");
            stream.Write(data, 0, data.Length);*/
            stream.Close();
            tcpClient.Close();
        }

        private void txtRemoteIp_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}
