﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace UDP_Sever
{
    public partial class Server : Form
    {
        public Server()
        {
            InitializeComponent();
            Thread udpServerThread = new Thread(serverThread);
            udpServerThread.Start();
            CheckForIllegalCrossThreadCalls = false;
        }
        public void serverThread()
        {
            UdpClient udpClient = new UdpClient(8080);

            while (true)
            {
                IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 0);

                Byte[] recivedBytes = udpClient.Receive(ref ipep);

                string returnData = Encoding.UTF8.GetString(recivedBytes);
                string mess = ipep.Address.ToString() + ":" + returnData.ToString();
                
                infoMessage(mess);

            }
            
        }
        public void infoMessage(string mess)
        {
            ListViewItem item = new ListViewItem();
            item.Text = mess;
            listMessage.Items.Add(item);
        }


        private void listMessage_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }

        }
        
    

