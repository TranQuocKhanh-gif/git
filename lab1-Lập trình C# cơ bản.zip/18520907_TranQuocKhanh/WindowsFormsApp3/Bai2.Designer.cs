﻿namespace WindowsFormsApp3
{
    partial class Bai2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.a = new System.Windows.Forms.Label();
            this.b = new System.Windows.Forms.Label();
            this.c = new System.Windows.Forms.Label();
            this.max = new System.Windows.Forms.Label();
            this.min = new System.Windows.Forms.Label();
            this.Nhap1 = new System.Windows.Forms.TextBox();
            this.Nhap2 = new System.Windows.Forms.TextBox();
            this.Nhap3 = new System.Windows.Forms.TextBox();
            this.LonNhat = new System.Windows.Forms.TextBox();
            this.NhoNhat = new System.Windows.Forms.TextBox();
            this.Tim = new System.Windows.Forms.Button();
            this.Xoa = new System.Windows.Forms.Button();
            this.Thoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // a
            // 
            this.a.AutoSize = true;
            this.a.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a.Location = new System.Drawing.Point(100, 88);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(94, 20);
            this.a.TabIndex = 0;
            this.a.Text = "Số thứ nhất";
            // 
            // b
            // 
            this.b.AutoSize = true;
            this.b.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b.Location = new System.Drawing.Point(100, 178);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(84, 20);
            this.b.TabIndex = 1;
            this.b.Text = "Số thứ hai";
            // 
            // c
            // 
            this.c.AutoSize = true;
            this.c.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c.Location = new System.Drawing.Point(100, 275);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(80, 20);
            this.c.TabIndex = 2;
            this.c.Text = "Số thứ ba";
            this.c.Click += new System.EventHandler(this.c_Click);
            // 
            // max
            // 
            this.max.AutoSize = true;
            this.max.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.max.Location = new System.Drawing.Point(100, 377);
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(93, 20);
            this.max.TabIndex = 3;
            this.max.Text = "Số lớn nhất";
            // 
            // min
            // 
            this.min.AutoSize = true;
            this.min.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.min.Location = new System.Drawing.Point(481, 377);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(89, 20);
            this.min.TabIndex = 4;
            this.min.Text = "Số bé nhất";
            // 
            // Nhap1
            // 
            this.Nhap1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nhap1.Location = new System.Drawing.Point(205, 88);
            this.Nhap1.Name = "Nhap1";
            this.Nhap1.Size = new System.Drawing.Size(100, 30);
            this.Nhap1.TabIndex = 5;
            this.Nhap1.Text = "ư";
            this.Nhap1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Nhap2
            // 
            this.Nhap2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nhap2.Location = new System.Drawing.Point(205, 178);
            this.Nhap2.Name = "Nhap2";
            this.Nhap2.Size = new System.Drawing.Size(100, 30);
            this.Nhap2.TabIndex = 6;
            this.Nhap2.TextChanged += new System.EventHandler(this.Nhap2_TextChanged);
            // 
            // Nhap3
            // 
            this.Nhap3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nhap3.Location = new System.Drawing.Point(205, 275);
            this.Nhap3.Name = "Nhap3";
            this.Nhap3.Size = new System.Drawing.Size(100, 30);
            this.Nhap3.TabIndex = 7;
            this.Nhap3.TextChanged += new System.EventHandler(this.Nhap3_TextChanged);
            // 
            // LonNhat
            // 
            this.LonNhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LonNhat.Location = new System.Drawing.Point(205, 374);
            this.LonNhat.Name = "LonNhat";
            this.LonNhat.ReadOnly = true;
            this.LonNhat.Size = new System.Drawing.Size(100, 28);
            this.LonNhat.TabIndex = 8;
            this.LonNhat.TextChanged += new System.EventHandler(this.LonNhat_TextChanged);
            // 
            // NhoNhat
            // 
            this.NhoNhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NhoNhat.Location = new System.Drawing.Point(600, 372);
            this.NhoNhat.Name = "NhoNhat";
            this.NhoNhat.ReadOnly = true;
            this.NhoNhat.Size = new System.Drawing.Size(100, 28);
            this.NhoNhat.TabIndex = 9;
            // 
            // Tim
            // 
            this.Tim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tim.Location = new System.Drawing.Point(515, 88);
            this.Tim.Name = "Tim";
            this.Tim.Size = new System.Drawing.Size(102, 34);
            this.Tim.TabIndex = 10;
            this.Tim.Text = "Tìm";
            this.Tim.UseVisualStyleBackColor = true;
            this.Tim.Click += new System.EventHandler(this.button1_Click);
            // 
            // Xoa
            // 
            this.Xoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Xoa.Location = new System.Drawing.Point(515, 166);
            this.Xoa.Name = "Xoa";
            this.Xoa.Size = new System.Drawing.Size(102, 35);
            this.Xoa.TabIndex = 11;
            this.Xoa.Text = "Xóa";
            this.Xoa.UseVisualStyleBackColor = true;
            this.Xoa.Click += new System.EventHandler(this.button2_Click);
            // 
            // Thoat
            // 
            this.Thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Thoat.Location = new System.Drawing.Point(515, 255);
            this.Thoat.Name = "Thoat";
            this.Thoat.Size = new System.Drawing.Size(102, 40);
            this.Thoat.TabIndex = 12;
            this.Thoat.Text = "Thoát";
            this.Thoat.UseVisualStyleBackColor = true;
            this.Thoat.Click += new System.EventHandler(this.button3_Click);
            // 
            // Bai2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Thoat);
            this.Controls.Add(this.Xoa);
            this.Controls.Add(this.Tim);
            this.Controls.Add(this.NhoNhat);
            this.Controls.Add(this.LonNhat);
            this.Controls.Add(this.Nhap3);
            this.Controls.Add(this.Nhap2);
            this.Controls.Add(this.Nhap1);
            this.Controls.Add(this.min);
            this.Controls.Add(this.max);
            this.Controls.Add(this.c);
            this.Controls.Add(this.b);
            this.Controls.Add(this.a);
            this.Name = "Bai2";
            this.Text = "Bai2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label a;
        private System.Windows.Forms.Label b;
        private System.Windows.Forms.Label c;
        private System.Windows.Forms.Label max;
        private System.Windows.Forms.Label min;
        private System.Windows.Forms.TextBox Nhap1;
        private System.Windows.Forms.TextBox Nhap2;
        private System.Windows.Forms.TextBox Nhap3;
        private System.Windows.Forms.TextBox LonNhat;
        private System.Windows.Forms.TextBox NhoNhat;
        private System.Windows.Forms.Button Tim;
        private System.Windows.Forms.Button Xoa;
        private System.Windows.Forms.Button Thoat;
    }
}