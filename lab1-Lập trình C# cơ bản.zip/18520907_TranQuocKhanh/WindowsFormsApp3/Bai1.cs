﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Bai1 : Form
    {
        public Bai1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void calc_Click(object sender, EventArgs e)
        {
            
            
            int num1, num2;
            long sum = 0;
            num1 = Int32.Parse(textBox1.Text.Trim());

                if (num1 <=0) 
                {

                    MessageBox.Show("VUi lòng nhập số nguyên");
                    this.textBox1.ResetText();
                    this.textBox2.ResetText();
                }
                else
                {
                    num2 = Int32.Parse(textBox2.Text.Trim());
                    if (num2 <=0)
                    {

                        MessageBox.Show("VUi lòng nhập số nguyên");
                        this.textBox1.ResetText();
                        this.textBox2.ResetText();

                    }
                    else
                    {
                        sum = num1 + num2;
                        textBox3.Text = sum.ToString();
                    }
                
            }
        }
        private void num1_Click(object sender, EventArgs e)
        {


        }

        private void num2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void menu_Click(object sender, EventArgs e)
        {
            this.menu.ForeColor = System.Drawing.Color.Red;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}








