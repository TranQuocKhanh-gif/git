﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private string chu_so (int n)
        {
            switch (n) // Trả về các giá trị
            {
                case 0: return "Không";
                case 1: return "Một";
                case 2: return "Hai";
                case 3: return "Ba";
                case 4: return "Bốn";
                case 5: return "Năm";
                case 6: return "Sáu";
                case 7: return "Bảy";
                case 8: return "Tám";
               default: return "Chín";
            }
        }
        private void button1_Click(object sender, EventArgs e) // 
        {
            string s, k; // Đọc các số thành chữ
            int d;
            s = textBox1.Text;
            if (s.Length == 1)
            {
                k = s.Substring(s.Length - 1, 1);
                d = int.Parse(k);
                s = chu_so(d);
                textBox2.Text = s;
            }
            else textBox2.Text = "Không có kết quả";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.ResetText();
            textBox2.ResetText();
        }
    }
}
