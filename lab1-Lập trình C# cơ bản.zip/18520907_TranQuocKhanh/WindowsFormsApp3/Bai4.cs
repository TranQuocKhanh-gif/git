﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Bai4 : Form
    {
        public Bai4()
        {
            InitializeComponent();
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {

            string list1;
            list1 = List1.SelectedItem.ToString();

            double num1, num2;

            num1 = Int32.Parse(textBox1.Text.Trim());
            num2 = 0;

            switch (list1)
            {
                case "EUR":
                    {
                        num2 = num1 * 28132;
                        textBox2.Text = num2.ToString();
                        textBox3.Text = "1 EUR = 28.132 VNĐ".ToString();
                        break;
                    }
                case "USD":
                    {
                        num2 = num1 * 22772;
                        textBox2.Text = num2.ToString();
                        textBox3.Text = "1 USD = 22.772 VNĐ".ToString();
                        break;
                    }
                case "SGD":
                    {
                        num2 = num1 * 17286;
                        textBox2.Text = num2.ToString();
                        textBox3.Text = "1 SGD = 17.286 VNĐ".ToString();
                        break;
                    }
                case "JPY":
                    {
                        num2 = num1 * 214;
                        textBox2.Text = num2.ToString();
                        textBox3.Text = "1 JPY = 214 VNĐ".ToString();
                        break;
                    }
                case "GBP":
                    {
                        num2 = num1 * 31538;
                        textBox2.Text = num2.ToString();
                        textBox3.Text = "1 GBP = 31.538 VNĐ".ToString();
                        break;
                    }

            }


        }











        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }



        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {

        }
    }
}
