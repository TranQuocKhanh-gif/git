﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b, c, max, min;
            a = Int32.Parse(Nhap1.Text.Trim());
            b = Int32.Parse(Nhap2.Text.Trim());
            c = Int32.Parse(Nhap3.Text.Trim());
            max = a;
            if (b > max)    // tìm số lớn nhất, nhỏ nhất
            {
                max = b;
            }
            if (c > max)
            {
                max = c;
            }
            LonNhat.Text = max.ToString();
            min = a;
            if (b < min)
            {
                min = b;
            }
            if (c < min)
            {
                min = c;
            }
            NhoNhat.Text = min.ToString();
        }
        private void button2_Click(object sender, EventArgs e) // Xóa hết các số vừa nhập và kết quả
        {
            Nhap1.ResetText();
            Nhap2.ResetText();
            Nhap3.ResetText();
            LonNhat.ResetText();
            NhoNhat.ResetText();
        }

        private void button3_Click(object sender, EventArgs e) // Thoát ra 
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Nhap2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Nhap3_TextChanged(object sender, EventArgs e)
        {

        }

        private void LonNhat_TextChanged(object sender, EventArgs e)
        {

        }

        private void c_Click(object sender, EventArgs e)
        {

        }
    }
}





