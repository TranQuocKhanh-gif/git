﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Bai5 : Form
    {
        public Bai5()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            int a;
            int x = 1;
            a = int.Parse(textbox1.Text.Trim());

            for (int i = 1; i <= a; i++)
                x = x * i;
            groupBox1.Text += "\n A! =" + x;
            int b;
            int y = 1;
            b = int.Parse(textbox2.Text.Trim());

            for (int j = 1; j <= b; j++)
                y = y * j;
            groupBox1.Text += "\n B!=" + y;
            int sum = 0;
            for (int i = 0; i <= a; i++)
                sum += i;
            groupBox1.Text += "\n S1= 1 + 2 + 3 + 4 + ... + A =" + sum;
            int tong = 0;
            for (int i = 0; i <= b; i++)
                tong += i;
            groupBox1.Text += "\n S2= 1 + 2 + 3 + 4 + ... + B =" + tong;
            int kq = 0;
            int lt = 1;
            for (int i = 1; i <= b; i++)
            {
                lt = lt * a;
                kq += lt;
            }
            groupBox1.Text += "\n S3= A^1+A^2+A^3+A^4+...+A^B =" + kq;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textbox1.ResetText();
            textbox2.ResetText();
            groupBox1.ResetText();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
