﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class LabTH1 : Form
    {
        public LabTH1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bai1 newform = new Bai1();
            newform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bai2 newform = new Bai2();
            newform.Show();
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            Bai3 newform = new Bai3();
            newform.Show();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Bai4 newform = new Bai4();
            newform.Show();

        }

        private void LabTH1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Bai5 newform = new Bai5();
            newform.Show();
        }
    }
}
