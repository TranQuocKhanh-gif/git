﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace lab2
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
            
            
        }

        private void DocFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);
            StreamReader sr = new StreamReader(fs);
            string content = sr.ReadToEnd();
            richTextBox1.Text = content;
            textBox1.Text = ofd.SafeFileName.ToString();
            textBox2.Text = fs.Name.ToString();
            string a = richTextBox1.Text;
            var lineCount = richTextBox1.Lines.Count();
            textBox3.Text = lineCount.ToString();
            string[] strSplit = null;
            strSplit = a.Split('\n', ' ');
            textBox4.Text = " " + strSplit.Length;
            textBox5.Text = " " + a.Replace('\r', ' ').Length;
            fs.Close();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}





