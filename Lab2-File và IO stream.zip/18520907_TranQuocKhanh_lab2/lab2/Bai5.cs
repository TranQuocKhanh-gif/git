﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace lab2
{
    public partial class Bai5 : Form
    {
        public Bai5()
        {
            InitializeComponent();

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        public void ScanDirectory(string directory, string searchPattern)
        {
            DirectoryInfo di = new DirectoryInfo("D:\\");
            FileInfo[] fiArr = di.GetFiles();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Browser_Click(object sender, EventArgs e, string file)
        {
            FileInfo finfo = new FileInfo(file);
            listView1.Invoke((Action)(() =>
            {
                var icon = Icon.ExtractAssociatedIcon(file);
                string key = Path.GetExtension(file);

                ListViewItem item = new ListViewItem(finfo.Name, key);
                item.SubItems.Add(finfo.DirectoryName);
                item.SubItems.Add(Math.Ceiling(finfo.Length / 1024f).ToString("0 KB"));
                listView1.BeginUpdate();

                listView1.Items.Add(item);
                listView1.EndUpdate();
            }));
        }

        private void btn_Browser_Click(object sender, EventArgs e)
        {

        }
    }
}

