﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace lab2
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        private void Bai3_Load(object sender, EventArgs e)
        {

        }

        private void DocFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            if (ofd.FileName.Length > 0)
            {
                FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                richTextBox1.Text = sr.ReadToEnd();
                sr.Close();
                fs.Close();
            }
        }
        public sealed class StackOverflowException : SystemException
        {

        }
        private void GhiFile_Click(object sender, EventArgs e)
        {

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.ShowDialog();
            FileStream fs = new FileStream(sfd.FileName, FileMode.CreateNew);
            StreamWriter sw = new StreamWriter(fs);
            if (richTextBox1.Lines.Length > 0)
            {
                foreach (var line in richTextBox1.Lines)
                {
                    if (line.Length == 0)
                        continue;
                    string[] arr = line.Split('+', '-', '*', '/');
                    
                    float S1, S2, KQ;
                    S1 = float.Parse(arr[0]);
                    S2 = float.Parse(arr[1]);
                    if (line.IndexOf('+') > 0)
                    {
                        KQ = S1 + S2;
                        sw.WriteLine(arr[0] + " + " + arr[1] + "=" + KQ.ToString());
                    }
                    else if (line.IndexOf('-') > 0)
                    {
                        KQ = S1 - S2;
                        sw.WriteLine(arr[0] + "-" + arr[1] + "=" + KQ.ToString());
                    }
                    else if (line.IndexOf('*') > 0)
                    {
                        KQ = S1 * S2;
                        sw.WriteLine(arr[0] + "*" + arr[1] + "=" + KQ.ToString());
                    }
                    else if (line.IndexOf('/') > 0)
                    {
                        KQ = S1 / S2;
                        sw.WriteLine(arr[0] + "/" + arr[1] + "=" + KQ.ToString());
                    }

                }
            }
            fs.Close();
        }



        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

