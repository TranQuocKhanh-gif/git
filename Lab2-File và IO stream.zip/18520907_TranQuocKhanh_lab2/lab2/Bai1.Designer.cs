﻿namespace lab2
{
    partial class Bai1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DocFile = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.GhiFile = new System.Windows.Forms.Button();
            this.Thoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DocFile
            // 
            this.DocFile.Location = new System.Drawing.Point(109, 80);
            this.DocFile.Name = "DocFile";
            this.DocFile.Size = new System.Drawing.Size(119, 58);
            this.DocFile.TabIndex = 0;
            this.DocFile.Text = "ĐỌC FILE";
            this.DocFile.UseVisualStyleBackColor = true;
            this.DocFile.Click += new System.EventHandler(this.DocFile_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(397, 65);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(380, 310);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // GhiFile
            // 
            this.GhiFile.Location = new System.Drawing.Point(109, 223);
            this.GhiFile.Name = "GhiFile";
            this.GhiFile.Size = new System.Drawing.Size(119, 58);
            this.GhiFile.TabIndex = 2;
            this.GhiFile.Text = "GHI FILE";
            this.GhiFile.UseVisualStyleBackColor = true;
            this.GhiFile.Click += new System.EventHandler(this.GhiFile_Click);
            // 
            // Thoat
            // 
            this.Thoat.Location = new System.Drawing.Point(109, 348);
            this.Thoat.Name = "Thoat";
            this.Thoat.Size = new System.Drawing.Size(119, 58);
            this.Thoat.TabIndex = 3;
            this.Thoat.Text = "THOÁT BÀI 1";
            this.Thoat.UseVisualStyleBackColor = true;
            this.Thoat.Click += new System.EventHandler(this.Thoat_Click);
            // 
            // Bai1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Thoat);
            this.Controls.Add(this.GhiFile);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.DocFile);
            this.Name = "Bai1";
            this.Text = "Bai1cs";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button DocFile;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button GhiFile;
        private System.Windows.Forms.Button Thoat;
    }
}