﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace lab2
{
    public partial class Bai4 : Form
    {
        public Bai4()
        {
            InitializeComponent();
        }
        [Serializable()]
        public class HocVien
        {
            public string mssv;
            public string hoten;
            public float toan;
            public float ly;
            public float hoa;
            public float tinhTrungBinh()
            {
                float result;
                result = (toan + ly + hoa) / 3;

                return 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HocVien hv = new HocVien();
            hv.mssv = txtMSSV.Text;
            hv.hoten = txtHoTen.Text;
            hv.toan = float.Parse(txtToan.Text);
            hv.ly = float.Parse(txtLy.Text);
            hv.hoa = float.Parse(txtHoa.Text);
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.ShowDialog();
            FileStream fs = new FileStream(sfd.FileName, FileMode.CreateNew);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, hv);
            fs.Close();
        }

        private void HienThi_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("hocvien.txt", FileMode.OpenOrCreate);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            listHocVien.Rows.Clear();
            //Dùng vòng lặp để lấy dữ liệu tất cả các đối tượng được lưu
            while (fs.Position != fs.Length)
            {
                //Lấy dữ liệu
                HocVien hv = (HocVien)binaryFormatter.Deserialize(fs);
                //Tạo 1 dòng mới của DataGridView để chứa dữ liệu hiển thị
                int rowIndex = listHocVien.Rows.Add();
                DataGridViewRow row = listHocVien.Rows[rowIndex];
                //Đưa dữ liệu vào DataGridView
                row.Cells["mssv"].Value = hv.mssv;



            }

            private void txtHoTen_TextChanged(object sender, EventArgs e)
            {

            }
        }
    }


