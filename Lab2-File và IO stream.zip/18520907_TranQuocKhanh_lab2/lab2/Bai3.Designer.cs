﻿namespace lab2
{
    partial class Bai3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DocFile = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.GhiFile = new System.Windows.Forms.Button();
            this.Thoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DocFile
            // 
            this.DocFile.Location = new System.Drawing.Point(69, 58);
            this.DocFile.Name = "DocFile";
            this.DocFile.Size = new System.Drawing.Size(119, 58);
            this.DocFile.TabIndex = 2;
            this.DocFile.Text = "ĐỌC FILE";
            this.DocFile.UseVisualStyleBackColor = true;
            this.DocFile.Click += new System.EventHandler(this.DocFile_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(380, 58);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(380, 310);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // GhiFile
            // 
            this.GhiFile.Location = new System.Drawing.Point(69, 235);
            this.GhiFile.Name = "GhiFile";
            this.GhiFile.Size = new System.Drawing.Size(119, 58);
            this.GhiFile.TabIndex = 4;
            this.GhiFile.Text = "GHI FILE";
            this.GhiFile.UseVisualStyleBackColor = true;
            this.GhiFile.Click += new System.EventHandler(this.GhiFile_Click);
            // 
            // Thoat
            // 
            this.Thoat.Location = new System.Drawing.Point(69, 370);
            this.Thoat.Name = "Thoat";
            this.Thoat.Size = new System.Drawing.Size(119, 58);
            this.Thoat.TabIndex = 5;
            this.Thoat.Text = "THOÁT";
            this.Thoat.UseVisualStyleBackColor = true;
            this.Thoat.Click += new System.EventHandler(this.Thoat_Click);
            // 
            // Bai3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Thoat);
            this.Controls.Add(this.GhiFile);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.DocFile);
            this.Name = "Bai3";
            this.Text = "Bai3";
            this.Load += new System.EventHandler(this.Bai3_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button DocFile;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button GhiFile;
        private System.Windows.Forms.Button Thoat;
    }
}