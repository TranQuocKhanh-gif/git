﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Web;

namespace lab4
{
    public partial class Bai4 : Form
    {
        public Bai4()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(tbURL.Text);
        }
        String source = ("viewsource.txt");
        private void btnViewSource_Click(object sender, EventArgs e)
        {
            
            StreamWriter writer = File.CreateText(source);
            writer.Write(webBrowser1.DocumentText);
            writer.Close();
            Process.Start("notepad.exe", source);
        }
        WebClient wc = new WebClient();
        private void btnDownload_Click(object sender, EventArgs e)
        {
            try
            {
                wc.DownloadFile(tbURL.Text, "D:\\uithcm.html");
                source = OpenReader("D:\\uithcm.html");
                MessageBox.Show("Đã download thành công", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                byte[] recv = new byte[1024];
                source = Encoding.UTF32.GetString(recv);
            }
            catch (WebException wex)
            {
                source = wex.Message;
            }
        }
        private string OpenReader(string argv)
        {
            string response = "";
            Stream strm = wc.OpenRead(argv);
            StreamReader sr = new StreamReader(strm);
            while (sr.Peek() > -1)
            {
                response += sr.ReadLine();
            }
            sr.Close();
            return response;
        }
    }
}
