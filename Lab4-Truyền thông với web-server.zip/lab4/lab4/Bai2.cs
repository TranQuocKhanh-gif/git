﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Web;
using System.IO;


namespace lab4
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }
        
        private string getHTTP(string szURL, string szPost)
        {
            HttpWebRequest httprequest;
            HttpWebResponse httpresponse;
            StreamReader bodyreader;
            string bodytext = "";
            Stream responsestream;
            Stream requestStream;
            httprequest = (HttpWebRequest)WebRequest.Create(szURL);
            httprequest.Method = "POST";
            httprequest.ContentType = "text/plain";
            httprequest.ContentLength = szPost.Length;
            requestStream = httprequest.GetRequestStream();
            requestStream.Write(Encoding.ASCII.GetBytes(szPost), 0, szPost.Length);

            requestStream.Close();
            httpresponse = (HttpWebResponse)httprequest.GetResponse();
            responsestream = httpresponse.GetResponseStream();
            bodyreader = new StreamReader(responsestream);
            bodytext = bodyreader.ReadToEnd();
            return bodytext;
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            rtbResult.Text = getHTTP(tbUrl.Text, "Lap Trinh Mang Can Ban" + tbPost.Text);
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
