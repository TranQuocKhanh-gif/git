﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab4
{
    public partial class Lab4 : Form
    {
        public Lab4()
        {
            InitializeComponent();
        }

        private void Lab4_Load(object sender, EventArgs e)
        {

        }

        private void Bai1_Click(object sender, EventArgs e)
        {
            Bai1 newform = new Bai1();
            newform.Show();
        }

        private void Bai2_Click(object sender, EventArgs e)
        {
            Bai2 newform = new Bai2();
            newform.Show();
        }

        private void Bai3_Click(object sender, EventArgs e)
        {
            Bai3 newform = new Bai3();
            newform.Show();
        }

        private void Bai4_Click(object sender, EventArgs e)
        {
            Bai4 newform = new Bai4();
            newform.Show();
        }
    }
}
