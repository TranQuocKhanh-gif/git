﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Net.Sockets;
namespace lab5_MoRong
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {
            MailMessage mess = new MailMessage();
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.Credentials = new NetworkCredential(txtTDN.Text, txtPass.Text);
            MessageBox.Show("Thành công");
            ListViewItem liEmail;
            Microsoft.Office.Interop.Outlook.Application App;
            Microsoft.Office.Interop.Outlook.MailItem Msg;
            Microsoft.Office.Interop.Outlook.NameSpace NS;
            Microsoft.Office.Interop.Outlook.MAPIFolder Inbox;
            Microsoft.Office.Interop.Outlook.Items Items;
            App = new Microsoft.Office.Interop.Outlook.Application();
            NS = App.GetNamespace("mapi");
            Inbox = NS.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);
            Items = Inbox.Items;
            for (int i = 1; i < Items.Count; i++)
            {
                Msg = (Microsoft.Office.Interop.Outlook.MailItem)Items[i];
                liEmail = lvOutlook.Items.Add(Msg.SenderName);
                liEmail.SubItems.Add(Msg.Subject);

            }
        } }
}
