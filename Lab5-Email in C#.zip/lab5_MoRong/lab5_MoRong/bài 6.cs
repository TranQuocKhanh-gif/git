﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Net.Sockets;

using System.Threading;
namespace lab5_MoRong
{
    public partial class Form1 : Form
    {
        Attachment attach = null;
        public Form1()
        {
            InitializeComponent();
            
        }
        

        private void btnAttach_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if(dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtFile.Text = dialog.FileName;
            }
        }
        
        private void btnSend_Click(object sender, EventArgs e)
        {
            attach = null;
            try
            {
                FileInfo file = new FileInfo(txtFile.Text);
                attach = new Attachment(txtFile.Text);
                MessageBox.Show("Gửi thành công");
            }
            catch 
            {

            }

            GuiMail(txtTDN.Text, txtTo.Text, txtSubject.Text, txtMessage.Text, attach);
        }
        void GuiMail(string from, string to, string subject, string message, Attachment file = null )
        {
            
            MailMessage mess = new MailMessage(from, to, subject, message);
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            if (attach != null)
            {
                mess.Attachments.Add(attach);
            }
            client.EnableSsl = true;
            client.Credentials = new NetworkCredential(txtTDN.Text, txtPass.Text);
            client.Send(mess);
            
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
